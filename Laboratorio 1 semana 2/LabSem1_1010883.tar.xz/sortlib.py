#Descripción: En este módulo contiene los algoritmos de ordenamiento de
#             simples: insertionsort, selectionsort, shellsort,
#             bubblesort
#
#
#Creado por: Juan Reyna
#email: 10-10883@usb.com

def insertion_sort(A):
    """Dado un arreglo de longitud n. Insertionsort toma uno por uno
       los elementos y se recorren hacia su posición con respecto a los
       anteriormente ordenados.

       Esta función devuelve el mismo arreglo ordenado"""

    m = A.index(min(A))
    n = len(A)
    A[0], A[m] = A[m], A[0]

    for i in range(1, n):
        j = i
        while A[j] < A[j-1]:
            A[j], A[j-1] = A[j-1], A[j]
            j -= 1
    return A


def selection_sort(A):
    """Dado un arreglo de longitud n. Selectionsort encuentra el menor
       de todos los elementos del arreglo e intercambiarlo con el que
       está en la primera posición. Luego el segundo mas pequeño,
       y así sucesivamente hasta ordenar todo el arreglo.

       Esta función devuelve el mismo arreglo ordenado"""

    n = len(A)
    for i in range(0, n):
        lowindex = i
        lowkey = A[i]
        for j in range(i+1, n):
            if A[j] < lowkey:
                lowkey = A[j]
                lowindex = j
        A[i], A[lowindex] = A[lowindex], A[i]
    return A


def shell_sort(A):

    n = len(A)
    incr = n // 2
    while incr > 0:
        for i in range(incr, n):
            j = i - incr
            while j > -1:
                if A[j] > A[j+incr]:
                    A[j], A[j + incr] = A[j + incr], A[j]
                    j = j - incr
                else:
                    j = -1
        incr = incr // 2
    return A


def bubble_sort(A):
    """Dado un arreglo de longitud n. Insertionsort Se recorre el
       arreglo intercambiando los elementos adjacentes que estén
       desordenados. Se recorre el arreglo tantas veces
       hasta que ya no haya cambios.

       Esta función devuelve el mismo arreglo ordenado"""

    n = len(A)
    for i in range(0, n):
        for j in range(n-1, i, -1):
            if A[j-1] > A[j]:
                A[j-1], A[j] = A[j], A[j-1]
    return A
